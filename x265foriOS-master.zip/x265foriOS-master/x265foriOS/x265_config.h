//
//  x265_config.h
//  x265foriOS
//
//  Created by Ruiwen Feng on 2017/5/27.
//  Copyright © 2017年 Ruiwen Feng. All rights reserved.
//

#ifndef x265_config_h
#define x265_config_h

#define X265_BUILD 116


#endif /* x265_config_h */
